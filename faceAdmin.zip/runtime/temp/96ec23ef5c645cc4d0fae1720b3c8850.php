<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"E:\Software\Apache24\htdocs\faceAdmin\public/../application/admin\view\index\add.html";i:1547474678;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>添加活动</title>

    <!--bootstrap4.0-->
    <link href="/faceAdmin/public/static/css/bootstrap.min.css" rel="stylesheet">
    <!--dashboard.css-->
    <link href="/faceAdmin/public/static/css/dashboard.css" rel="stylesheet">
</head>

<body>
<nav class="navbar navbar-dark sticky-top bg-dark flex-md-nowrap p-0">
    <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">人脸识别签到系统</a>
    <input class="form-control form-control-dark w-100" type="text" placeholder="Search" aria-label="Search">
    <ul class="navbar-nav px-3">
        <li class="nav-item text-nowrap">
            <a class="nav-link" href="#">退出</a>
        </li>
    </ul>
</nav>

<div class="container-fluid">
    <div class="row">
        <nav class="col-md-2 d-none d-md-block bg-light sidebar">
            <div class="sidebar-sticky">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">
                            <span data-feather="home"></span>
                            活动相关 <span class="sr-only">(current)</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <span data-feather="file"></span>
                            历史纪录
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <span data-feather="shopping-cart"></span>
                            Products
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <span data-feather="users"></span>
                            Customers
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <span data-feather="bar-chart-2"></span>
                            Reports
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <span data-feather="layers"></span>
                            Integrations
                        </a>
                    </li>
                </ul>

                <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                    <span>Saved reports</span>
                    <a class="d-flex align-items-center text-muted" href="#">
                        <span data-feather="plus-circle"></span>
                    </a>
                </h6>
                <ul class="nav flex-column mb-2">
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <span data-feather="file-text"></span>
                            Current month
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <span data-feather="file-text"></span>
                            Last quarter
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <span data-feather="file-text"></span>
                            Social engagement
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <span data-feather="file-text"></span>
                            Year-end sale
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">


            <h2>添加活动</h2>
            <div class="divform">
                <form action="<?php echo url('Index/addActivity'); ?>" enctype="multipart/form-data" method="post">
                    <div class="form-group row">
                        <label for="inputName" class="col-sm-2 col-form-label">活动名称</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="inputName" name="actName" placeholder="活动名称">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputTime" class="col-sm-2 col-form-label">活动时间</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" id="inputTime" placeholder="活动时间">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputAddress" class="col-sm-2 col-form-label">活动地点</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="inputAddress" placeholder="活动地点">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputMaster" class="col-sm-2 col-form-label">组织者</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="inputMaster" placeholder="组织者">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="listFile">参与者名单</label>
                        <input type="file" class="form-control-file" id="listFile" name="listFile">
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">添加</button>
                        </div>
                    </div>
                </form>
            </div>
        </main>
    </div>
</div>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<!--jquery-->
<script src="/faceAdmin/public/static/js/jquery-3.3.1.min.js"></script>
<!--bootstrap-->
<script src="/faceAdmin/public/static/js/bootstrap.min.js"></script>
<script src="/faceAdmin/public/static/js/popper.min.js"></script>
<!-- Icons -->
<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>

<!-- Icons -->
<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
<script>
    feather.replace()
</script>


</body>
</html>
