<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/18 0018
 * Time: 11:09
 */

namespace app\Admin\model;


use think\Model;

class actDetail extends Model
{
    protected $table = "activitydetail";

}