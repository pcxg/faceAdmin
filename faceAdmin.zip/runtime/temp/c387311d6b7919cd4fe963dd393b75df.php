<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:87:"E:\Software\Apache24\htdocs\faceAdmin\public/../application/login\view\index\index.html";i:1547812720;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>人脸签到系统登陆界面</title>

    <!-- Bootstrap core CSS -->
    <link href="/faceAdmin/public/static/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="/faceAdmin/public/static/css/signin.css" rel="stylesheet">
</head>

<body class="text-center">
<form class="form-signin" action="<?php echo url('Index/login'); ?>" method="post">
    <img class="mb-4" src="https://getbootstrap.com/assets/brand/bootstrap-solid.svg" alt="" width="72" height="72">
    <h1 class="h3 mb-3 font-weight-normal">欢迎！</h1>
    <label for="inputName" class="sr-only">用户名</label>
    <input type="text" id="inputName" class="form-control" placeholder="用户名" name="user_name" required autofocus>
    <label for="inputPassword" class="sr-only">密码</label>
    <input type="password" id="inputPassword" class="form-control" placeholder="密码" name="user_pwd" required>
    <div class="checkbox mb-3">
        <label>
            <input type="checkbox" value="remember-me"> 记住我
        </label>
    </div>
    <button class="btn btn-lg btn-primary btn-block" type="submit">登陆</button>

</form>
</body>
</html>
